﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Mili_jonerzy
{
    public partial class Form1 : Form
    {
        // quiz game variables
        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;
        public Form1()
        {
            InitializeComponent();
            askQuestion(questionNumber);
            totalQuestions = 8;
        }
        private void checkAnswerEvent(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;
            int buttonTag = Convert.ToInt32(senderObject.Tag);
            if (buttonTag == correctAnswer)
            {
                score++;
            }
            if (questionNumber == totalQuestions)
            {
                // work out the percentage
                percentage = (int)Math.Round((double)(score * 100) / totalQuestions);
                MessageBox.Show(
                "Quiz Ended!" + Environment.NewLine +
                "You have answered " + score + " questions correctly." + Environment.NewLine +
                "Your total percentage is " + percentage + "%" + Environment.NewLine +
                "Click OK to play again"
                );
                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);
            }
            questionNumber++;
            askQuestion(questionNumber);
        }
        private void askQuestion(int qnum)
        {
            switch (qnum)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.ford;
                    lblQuestion.Text = "Jaka to marka auta?";
                    button1.Text = "ford";
                    button2.Text = "honda";
                    button3.Text = "bmw";
                    button4.Text = "bugatti";
                    correctAnswer = 1;
                    break;
                case 2:
                    pictureBox1.Image = Properties.Resources.audi;
                    lblQuestion.Text = "Jaka to marka auta?";
                    button1.Text = "BMW";
                    button2.Text = "audi";
                    button3.Text = "honda";
                    button4.Text = "toyota";
                    correctAnswer = 2;
                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.bmw;
                    lblQuestion.Text = "Jaka to marka auta?";
                    button1.Text = "Ferrari";
                    button2.Text = "Lamborghini";
                    button3.Text = "Maserati";
                    button4.Text = "bmw";
                    correctAnswer = 4;
                    break;
                case 4:
                    pictureBox1.Image = Properties.Resources.honda;
                    lblQuestion.Text = "Jaka to marka auta?";
                    button1.Text = "lamborgini";
                    button2.Text = "skoda";
                    button3.Text = "honda";
                    button4.Text = "fiat";
                    correctAnswer = 3;
                    break;
                case 5:
                    pictureBox1.Image = Properties.Resources.neault;
                    lblQuestion.Text = "Jaka to marka auta?";
                    button1.Text = "reanult";
                    button2.Text = "ford";
                    button3.Text = "fiat";
                    button4.Text = "audi";
                    correctAnswer = 1;
                    break;
                case 6:
                    pictureBox1.Image = Properties.Resources.mercedes;
                    lblQuestion.Text = "Jaka to marka auta?";
                    button1.Text = "bmw";
                    button2.Text = "maseratti";
                    button3.Text = "mercedes";
                    button4.Text = "nissan";
                    correctAnswer = 3;
                    break;
                case 7:
                    pictureBox1.Image = Properties.Resources.toyota;
                    lblQuestion.Text = "Jaka to marka auta?";
                    button1.Text = "audi";
                    button2.Text = "skoda";
                    button3.Text = "toyota";
                    button4.Text = "fiat";
                    correctAnswer = 3;
                    break;
                case 8:
                    pictureBox1.Image = Properties.Resources.fiat;
                    lblQuestion.Text = "Jaka to marka auta?";
                    button1.Text = "mercedes";
                    button2.Text = "bmw";
                    button3.Text = "ford";
                    button4.Text = "fiat";
                    correctAnswer = 4;
                    break;
            }
        }
    }
}